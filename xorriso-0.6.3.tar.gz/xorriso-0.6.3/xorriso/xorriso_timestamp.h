#define Xorriso_timestamP "2010.10.15.125440"
