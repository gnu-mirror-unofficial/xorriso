#define Xorriso_timestamP "2013.11.17.120422"
