#define Xorriso_timestamP "2011.01.17.092111"
