#define Xorriso_timestamP "2011.08.08.070301"
