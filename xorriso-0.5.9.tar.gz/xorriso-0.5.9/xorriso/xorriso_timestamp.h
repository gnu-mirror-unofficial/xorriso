#define Xorriso_timestamP "2010.06.26.114315"
