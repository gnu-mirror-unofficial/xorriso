#define Xorriso_timestamP "2010.12.02.111029"
