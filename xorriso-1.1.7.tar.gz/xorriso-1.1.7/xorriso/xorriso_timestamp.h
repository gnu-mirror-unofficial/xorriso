#define Xorriso_timestamP "2011.09.27.133025"
